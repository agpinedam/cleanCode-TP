package org.mines.address.port.driving;

import org.mines.address.domain.model.Statistics;

public interface StatisticsUseCase {

    Statistics getStatistics();
}
